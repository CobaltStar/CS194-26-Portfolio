Name: Archit Das
SID: 3035559708
Email: archit.das@berkeley.edu
Link to website: https://inst.eecs.berkeley.edu/~cs194-26/fa22/upload/files/proj5/cs194-26-adc/

All functionality for part 1 is in Part1.py. All functionality for part 2 is in Part2.py. All functionality for part 3 and part 4 are in Part3andPart4.py, with a distinct comment saying when part 3 ends and part 4 begins. My own personal images have also been provided to for predicitons.